﻿using System;

namespace CustomThreadPoolTask
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
            
            Console.WriteLine("\n----------=======DotNet ThreadPool tests=======----------");
            new DotNetThreadPoolWrapperTests().RunTests();

            Console.WriteLine();
        }
    }
}