﻿namespace DataParallelism
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // ProgramParallel.Demo();
            ProgramPlinq.Demo();
        }
    }
}